package javaucjc.ejercicios.herencia.maniqui;

public class Vestido extends Ropa{
	
	public Vestido (String color, String talla, double precio) {
		super(color,talla, precio);
		System.out.println("");
		
	}
	
}
