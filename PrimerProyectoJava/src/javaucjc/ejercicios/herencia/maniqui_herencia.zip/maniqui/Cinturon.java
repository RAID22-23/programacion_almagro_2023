package javaucjc.ejercicios.herencia.maniqui;

public class Cinturon {


	
}
