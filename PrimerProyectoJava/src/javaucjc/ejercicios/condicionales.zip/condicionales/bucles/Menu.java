package javaucjc.ejercicios.condicionales.bucles;

import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {

		int opcion=0;
		do {
			System.out.println("1. Validar email");
			System.out.println("2. Pintar cuadrado");
			System.out.println("3. Mostrar datos");
			System.out.println("4. Salir");

			System.out.println("Elige una opcion");
			Scanner scan = new Scanner(System.in);
			opcion = scan.nextInt();
			System.out.println(opcion);
			
			switch (opcion) {
				case 1: System.out.println("Opcion 1");break;
				case 2: pintaCuadrado(5);break;
				case 3: System.out.println("Opcion 3");break;
				case 4: System.out.println("Adios!");break;
				default: System.out.println("Opción incorrecta");
				
			}
			
			

		} while (opcion != 4);

	}
	
	public static void pintaCuadrado(int size) {
		
		for (int i=0; i<size;i++) {//Filas
			for (int j=0; j<size;j++) {//Columnas
				if (i==0 || i==size-1) {
					System.out.print("*\t");
				}else {
					if (j==0|| j==size-1) {
						System.out.print("*\t");
					}else {
						System.out.print(" \t");
					}
				}
			}
			//System.out.print("\n");
			System.out.println();
		}
		
	}
	

}




