package javaucjc.ejercicios.condicionales.bucles;

public class ParesImpares {

	public static void main(String[] args) {
		
		for (int par=0, impar=99 ; par<=100 ; par+=2,impar-=2 ) {
			System.out.println(par + "," +impar);
		}
		

	}

}
