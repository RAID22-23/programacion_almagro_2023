package javaucjc.bucles;

public class BuclesWhileDoWhile {

	public static void main(String[] args) {
		//While
		int num = 4;
		while (num<=4) {
			System.out.println(num);
			num++;
		}
		
		
		//Do-While
		do {
			System.out.println(num);
		}while(num>3);
		

	}

}
